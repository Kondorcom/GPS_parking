/**
 * 
 */
/**
 * @author kondor
 *
 */
package com.kondorcom.gpsparking.model;